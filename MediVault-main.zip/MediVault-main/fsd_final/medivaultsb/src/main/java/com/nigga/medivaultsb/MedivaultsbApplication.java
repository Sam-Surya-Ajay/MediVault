package com.nigga.medivaultsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedivaultsbApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedivaultsbApplication.class, args);
    }

}
